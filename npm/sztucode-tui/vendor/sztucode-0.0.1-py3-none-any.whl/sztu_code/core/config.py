from __future__ import annotations

import json
import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

_DEFAULT_HOST = "127.0.0.1"
_DEFAULT_PORT = 7437
_DEFAULT_LOG_LEVEL = "INFO"
_DEFAULT_LOG_FILE = "~/.sztu/logs/core.log"
_DEFAULT_LOG_FORMAT = "text"
_DEFAULT_CONFIG_PATH = "~/.sztu/config.toml"
_DEFAULT_CLIENT_SETTINGS_PATH = "~/.sztu/client-settings.json"
_DEFAULT_MAX_STEPS = 0  # 0 = 不限步数（预算驱动，由 token/墙钟兜底）
_DEFAULT_WRAP_UP_ON_MAX_STEPS = True
_DEFAULT_GRACE_STEP_ON_MAX_STEPS = True
_DEFAULT_STUCK_MAX_FAILURES = 3
_DEFAULT_STUCK_MAX_TOTAL = 0
_DEFAULT_TRACE_FILE = "~/.sztu/traces/daemon.jsonl"


@dataclass
class LoggingConfig:
    level: str = _DEFAULT_LOG_LEVEL
    file: str = _DEFAULT_LOG_FILE
    format: str = _DEFAULT_LOG_FORMAT  # "text" | "json"


@dataclass
class AgentConfig:
    max_steps: int = _DEFAULT_MAX_STEPS  # 0 = 不限步数；预算由 budget.max_tokens / max_wall_clock_s 兜底
    # max_steps 到达前给一次总结回合，避免裸失败
    wrap_up_on_max_steps: bool = _DEFAULT_WRAP_UP_ON_MAX_STEPS
    # max_steps 边界且最后一步工具全部成功时，追加一步无工具结语回合让模型正常收尾
    grace_step_on_max_steps: bool = _DEFAULT_GRACE_STEP_ON_MAX_STEPS
    # 同一操作连续失败达到该次数触发软干预；0=关闭
    stuck_max_failures: int = _DEFAULT_STUCK_MAX_FAILURES
    # 累计干预达到该次数硬停；0=永不硬停
    stuck_max_total: int = _DEFAULT_STUCK_MAX_TOTAL


@dataclass
class BudgetConfig:
    # 本 run 累计 input+output tokens 上限；0=不限
    max_tokens: int = 0
    # 本 run 累计墙钟秒数上限；0=不限
    max_wall_clock_s: int = 0


@dataclass
class LlmConfig:
    # A model must be supplied by configuration; never silently select a vendor model.
    default_model: str = ""
    provider: str = "anthropic"  # "anthropic" | "openai"
    router: str = "static"  # "static" | "rule_based" (S4) | "cost_budget" (S6)
    context_window: int = 0  # 0 = use provider's model-aware default
    base_url: str = ""  # 自定义端点，空表示使用官方默认地址
    api_key: str = ""  # 导入的凭证，优先于 .env 注入 provider 环境
    api_key_env: str = ""  # 内置模型使用的凭证变量名，避免把密钥写入模型配置
    keyless: bool = False  # 免 key 端点（如 opencode Zen 免费模型），跳过凭证校验


@dataclass
class TraceConfig:
    enabled: bool = True
    file: str = _DEFAULT_TRACE_FILE
    include_llm_payload: bool = True  # false 时 LLM 记录只保留摘要


@dataclass
class PermissionConfig:
    timeout_s: float = 60.0  # 审批超时秒数；0 表示不超时
    mode: str = "normal"


@dataclass
class CompactionConfig:
    auto_threshold: float = 0.0  # 0 disables auto compaction; manual /compact remains available
    tool_result_limit: int = 8_000
    tool_result_keep: int = 4_000


@dataclass
class OffloadConfig:
    enabled: bool = True  # 是否启用上下文卸载
    min_chars: int = 2_000  # 触发卸载的最小字符数
    min_lines: int = 50  # 触发卸载的最小行数
    force_tools: list[str] = field(default_factory=lambda: ["bash", "grep", "glob"])
    summary_max_chars: int = 300  # 摘要最大字符数


@dataclass
class McpServerConfig:
    name: str
    transport: str = "stdio"       # "stdio" | "tcp"
    command: str = ""              # stdio 专用：可执行文件路径
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    host: str = "localhost"        # tcp 专用
    port: int = 3000               # tcp 专用


@dataclass
class McpConfig:
    servers: list[McpServerConfig] = field(default_factory=list)


@dataclass
class SztuConfig:
    host: str = _DEFAULT_HOST
    port: int = _DEFAULT_PORT
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    llm: LlmConfig = field(default_factory=LlmConfig)
    trace: TraceConfig = field(default_factory=TraceConfig)
    permission: PermissionConfig = field(default_factory=PermissionConfig)
    compaction: CompactionConfig = field(default_factory=CompactionConfig)
    offload: OffloadConfig = field(default_factory=OffloadConfig)
    budget: BudgetConfig = field(default_factory=BudgetConfig)
    mcp: McpConfig = field(default_factory=McpConfig)


# 构建并返回运行时配置：默认值 → 全局 TOML → 项目本地 TOML → .env → 系统环境变量（后者优先级最高）
def get_config() -> SztuConfig:
    config = SztuConfig()

    # .env 必须在读取 SZTU_CONFIG 之前加载，以便 .env 中的 SZTU_CONFIG 能影响 TOML 路径
    load_dotenv(".env", override=False)

    # 若显式指定 SZTU_CONFIG，只读该文件；否则按优先级叠加：全局 → 项目本地
    explicit = os.environ.get("SZTU_CONFIG")
    if explicit:
        config_paths = [Path(explicit).expanduser()]
    else:
        config_paths = [
            Path(_DEFAULT_CONFIG_PATH).expanduser(),
            Path(".sztu/config.toml"),
        ]

    for config_path in config_paths:
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    data = tomllib.load(f)
            except tomllib.TOMLDecodeError as e:
                raise SystemExit(f"Config parse error ({config_path}): {e}") from e
            _apply_toml(config, data)

    _apply_client_settings(config)

    _apply_env(config)
    return config


def _client_settings_path() -> Path:
    return Path(
        os.environ.get("SZTU_CLIENT_SETTINGS", _DEFAULT_CLIENT_SETTINGS_PATH)
    ).expanduser()


def _read_client_settings() -> dict[str, Any]:
    path = _client_settings_path()
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _apply_client_settings(config: SztuConfig) -> None:
    value = _read_client_settings()
    provider = value.get("provider")
    model = value.get("model")
    permission_mode = value.get("permission_mode")
    if provider in {"anthropic", "openai"}:
        config.llm.provider = str(provider)
    if isinstance(model, str) and model:
        config.llm.default_model = model
        # 让客户端显式保存的模型优先于 .env 里的 KAMA_LLM_DEFAULT_MODEL 默认值
        os.environ["SZTU_LLM_DEFAULT_MODEL"] = model
    if permission_mode in {"normal", "accept_edits", "plan", "auto"}:
        config.permission.mode = str(permission_mode)
    if isinstance(value.get("base_url"), str):
        config.llm.base_url = value["base_url"]
    if isinstance(value.get("api_key"), str):
        config.llm.api_key = value["api_key"]
    if isinstance(value.get("api_key_env"), str):
        config.llm.api_key_env = value["api_key_env"]
    # 免 key 标志持久化：重启后仍能正确识别 Zen 等免 key 端点，避免泄漏环境里的通用 key
    if isinstance(value.get("keyless"), bool):
        config.llm.keyless = value["keyless"]


def load_model_profiles() -> tuple[list[dict[str, Any]], str]:
    value = _read_client_settings()
    profiles = value.get("models")
    return (
        [item for item in profiles if isinstance(item, dict)]
        if isinstance(profiles, list)
        else [],
        str(value.get("active_model_id", "") or ""),
    )


def save_client_settings(
    config: SztuConfig,
    *,
    models: list[dict[str, Any]] | None = None,
    active_model_id: str | None = None,
) -> Path:
    """持久化桌面可编辑字段；base_url/api_key 为导入的本地凭证（与 cc-switch 同级明文存储）"""
    path = _client_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    value = _read_client_settings()
    value.update(
        {
            "provider": config.llm.provider,
            "model": config.llm.default_model,
            "permission_mode": config.permission.mode,
            "base_url": config.llm.base_url,
            "api_key": config.llm.api_key,
            "api_key_env": config.llm.api_key_env,
            "keyless": config.llm.keyless,
        }
    )
    if models is not None:
        value["models"] = models
    if active_model_id is not None:
        value["active_model_id"] = active_model_id
    temporary.write_text(
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


# 将已解析的 TOML 根表写入 config；未知小节或类型错误时退出进程
def _apply_toml(config: SztuConfig, data: dict[str, Any]) -> None:
    unknown = set(data.keys()) - {
        "core",
        "logging",
        "agent",
        "llm",
        "trace",
        "permission",
        "compaction",
        "offload",
        "budget",
        "mcp",
    }
    if unknown:
        raise SystemExit(f"Unknown top-level config keys: {', '.join(sorted(unknown))}")

    if "core" in data:
        core = data["core"]
        if not isinstance(core, dict):
            raise SystemExit("Config error: [core] must be a table")
        unknown_core: set[str] = set(core.keys()) - {"host", "port"}
        if unknown_core:
            raise SystemExit(f"Unknown [core] keys: {', '.join(sorted(unknown_core))}")
        if "host" in core:
            val = core["host"]
            if not isinstance(val, str):
                raise SystemExit("Config error: core.host must be a string")
            config.host = val
        if "port" in core:
            val = core["port"]
            if not isinstance(val, int):
                raise SystemExit("Config error: core.port must be an integer")
            config.port = val

    if "logging" in data:
        log = data["logging"]
        if not isinstance(log, dict):
            raise SystemExit("Config error: [logging] must be a table")
        unknown_log: set[str] = set(log.keys()) - {"level", "file", "format"}
        if unknown_log:
            raise SystemExit(f"Unknown [logging] keys: {', '.join(sorted(unknown_log))}")
        for key in ("level", "file", "format"):
            if key in log:
                val = log[key]
                if not isinstance(val, str):
                    raise SystemExit(f"Config error: logging.{key} must be a string")
                setattr(config.logging, key, val)

    if "agent" in data:
        agent = data["agent"]
        if not isinstance(agent, dict):
            raise SystemExit("Config error: [agent] must be a table")
        unknown_agent: set[str] = set(agent.keys()) - {
            "max_steps", "wrap_up_on_max_steps", "grace_step_on_max_steps",
            "stuck_max_failures", "stuck_max_total",
        }
        if unknown_agent:
            raise SystemExit(f"Unknown [agent] keys: {', '.join(sorted(unknown_agent))}")
        if "max_steps" in agent:
            val = agent["max_steps"]
            if not isinstance(val, int) or val < 0:
                raise SystemExit("Config error: agent.max_steps must be a non-negative integer (0 = unlimited)")
            config.agent.max_steps = val
        if "wrap_up_on_max_steps" in agent:
            val = agent["wrap_up_on_max_steps"]
            if not isinstance(val, bool):
                raise SystemExit("Config error: agent.wrap_up_on_max_steps must be a boolean")
            config.agent.wrap_up_on_max_steps = val
        if "grace_step_on_max_steps" in agent:
            val = agent["grace_step_on_max_steps"]
            if not isinstance(val, bool):
                raise SystemExit("Config error: agent.grace_step_on_max_steps must be a boolean")
            config.agent.grace_step_on_max_steps = val
        for _key in ("stuck_max_failures", "stuck_max_total"):
            if _key in agent:
                val = agent[_key]
                if not isinstance(val, int) or val < 0:
                    raise SystemExit(f"Config error: agent.{_key} must be a non-negative integer")
                setattr(config.agent, _key, val)

    if "budget" in data:
        budget = data["budget"]
        if not isinstance(budget, dict):
            raise SystemExit("Config error: [budget] must be a table")
        unknown_budget: set[str] = set(budget.keys()) - {"max_tokens", "max_wall_clock_s"}
        if unknown_budget:
            raise SystemExit(f"Unknown [budget] keys: {', '.join(sorted(unknown_budget))}")
        for _key in ("max_tokens", "max_wall_clock_s"):
            if _key in budget:
                val = budget[_key]
                if not isinstance(val, int) or val < 0:
                    raise SystemExit(f"Config error: budget.{_key} must be a non-negative integer")
                setattr(config.budget, _key, val)

    if "llm" in data:
        llm = data["llm"]
        if not isinstance(llm, dict):
            raise SystemExit("Config error: [llm] must be a table")
        unknown_llm: set[str] = set(llm.keys()) - {
            "default_model",
            "provider",
            "router",
            "context_window",
        }
        if unknown_llm:
            raise SystemExit(f"Unknown [llm] keys: {', '.join(sorted(unknown_llm))}")
        if "default_model" in llm:
            val = llm["default_model"]
            if not isinstance(val, str):
                raise SystemExit("Config error: llm.default_model must be a string")
            config.llm.default_model = val
        if "provider" in llm:
            val = llm["provider"]
            if not isinstance(val, str) or val not in ("anthropic", "openai"):
                raise SystemExit(
                    "Config error: llm.provider must be 'anthropic' or 'openai'"
                )
            config.llm.provider = val
        if "router" in llm:
            val = llm["router"]
            if not isinstance(val, str):
                raise SystemExit("Config error: llm.router must be a string")
            config.llm.router = val
        if "context_window" in llm:
            val = llm["context_window"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit("Config error: llm.context_window must be a positive integer")
            config.llm.context_window = val

    if "trace" in data:
        trace = data["trace"]
        if not isinstance(trace, dict):
            raise SystemExit("Config error: [trace] must be a table")
        unknown_trace: set[str] = set(trace.keys()) - {"enabled", "file", "include_llm_payload"}
        if unknown_trace:
            raise SystemExit(f"Unknown [trace] keys: {', '.join(sorted(unknown_trace))}")
        if "enabled" in trace:
            val = trace["enabled"]
            if not isinstance(val, bool):
                raise SystemExit("Config error: trace.enabled must be a boolean")
            config.trace.enabled = val
        if "file" in trace:
            val = trace["file"]
            if not isinstance(val, str):
                raise SystemExit("Config error: trace.file must be a string")
            config.trace.file = val
        if "include_llm_payload" in trace:
            val = trace["include_llm_payload"]
            if not isinstance(val, bool):
                raise SystemExit("Config error: trace.include_llm_payload must be a boolean")
            config.trace.include_llm_payload = val

    if "permission" in data:
        perm = data["permission"]
        if not isinstance(perm, dict):
            raise SystemExit("Config error: [permission] must be a table")
        unknown_perm: set[str] = set(perm.keys()) - {"timeout_s", "mode"}
        if unknown_perm:
            raise SystemExit(f"Unknown [permission] keys: {', '.join(sorted(unknown_perm))}")
        if "timeout_s" in perm:
            val = perm["timeout_s"]
            if not isinstance(val, (int, float)) or val < 0:
                raise SystemExit("Config error: permission.timeout_s must be a non-negative number")
            config.permission.timeout_s = float(val)
        if "mode" in perm:
            val = perm["mode"]
            if val not in {"normal", "accept_edits", "plan", "auto"}:
                raise SystemExit("Config error: permission.mode is invalid")
            config.permission.mode = str(val)

    if "compaction" in data:
        comp = data["compaction"]
        if not isinstance(comp, dict):
            raise SystemExit("Config error: [compaction] must be a table")
        unknown_comp: set[str] = set(comp.keys()) - {
            "auto_threshold",
            "tool_result_limit",
            "tool_result_keep",
        }
        if unknown_comp:
            raise SystemExit(f"Unknown [compaction] keys: {', '.join(sorted(unknown_comp))}")
        if "auto_threshold" in comp:
            val = comp["auto_threshold"]
            if not isinstance(val, (int, float)) or not (0.0 <= val <= 1.0):
                raise SystemExit("Config error: compaction.auto_threshold must be between 0 and 1")
            config.compaction.auto_threshold = float(val)
        if "tool_result_limit" in comp:
            val = comp["tool_result_limit"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit(
                    "Config error: compaction.tool_result_limit must be a positive integer"
                )
            config.compaction.tool_result_limit = val
        if "tool_result_keep" in comp:
            val = comp["tool_result_keep"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit(
                    "Config error: compaction.tool_result_keep must be a positive integer"
                )
            config.compaction.tool_result_keep = val

    if "offload" in data:
        off = data["offload"]
        if not isinstance(off, dict):
            raise SystemExit("Config error: [offload] must be a table")
        unknown_off: set[str] = set(off.keys()) - {
            "enabled", "min_chars", "min_lines", "force_tools", "summary_max_chars",
        }
        if unknown_off:
            raise SystemExit(f"Unknown [offload] keys: {', '.join(sorted(unknown_off))}")
        if "enabled" in off:
            val = off["enabled"]
            if not isinstance(val, bool):
                raise SystemExit("Config error: offload.enabled must be a boolean")
            config.offload.enabled = val
        if "min_chars" in off:
            val = off["min_chars"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit("Config error: offload.min_chars must be a positive integer")
            config.offload.min_chars = val
        if "min_lines" in off:
            val = off["min_lines"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit("Config error: offload.min_lines must be a positive integer")
            config.offload.min_lines = val
        if "force_tools" in off:
            val = off["force_tools"]
            if not isinstance(val, list) or not all(isinstance(t, str) for t in val):
                raise SystemExit("Config error: offload.force_tools must be a list of strings")
            config.offload.force_tools = val
        if "summary_max_chars" in off:
            val = off["summary_max_chars"]
            if not isinstance(val, int) or val <= 0:
                raise SystemExit(
                    "Config error: offload.summary_max_chars must be a positive integer"
                )
            config.offload.summary_max_chars = val

    if "mcp" in data:
        mcp = data["mcp"]
        if not isinstance(mcp, dict):
            raise SystemExit("Config error: [mcp] must be a table")
        unknown_mcp: set[str] = set(mcp.keys()) - {"servers"}
        if unknown_mcp:
            raise SystemExit(f"Unknown [mcp] keys: {', '.join(sorted(unknown_mcp))}")
        servers_raw = mcp.get("servers", [])
        if not isinstance(servers_raw, list):
            raise SystemExit("Config error: mcp.servers must be an array of tables")
        for i, srv in enumerate(servers_raw):
            if not isinstance(srv, dict):
                raise SystemExit(f"Config error: mcp.servers[{i}] must be a table")
            name = srv.get("name")
            if not isinstance(name, str) or not name:
                raise SystemExit(f"Config error: mcp.servers[{i}].name must be a non-empty string")
            transport = srv.get("transport", "stdio")
            if transport not in ("stdio", "tcp"):
                raise SystemExit(
                    f"Config error: mcp.servers[{i}].transport must be 'stdio' or 'tcp'"
                )
            s = McpServerConfig(name=name, transport=transport)
            if "command" in srv:
                val = srv["command"]
                if not isinstance(val, str):
                    raise SystemExit(f"Config error: mcp.servers[{i}].command must be a string")
                s.command = val
            if "args" in srv:
                val = srv["args"]
                if not isinstance(val, list):
                    raise SystemExit(f"Config error: mcp.servers[{i}].args must be an array")
                s.args = [str(a) for a in val]
            if "env" in srv:
                val = srv["env"]
                if not isinstance(val, dict):
                    raise SystemExit(f"Config error: mcp.servers[{i}].env must be a table")
                s.env = {str(k): str(v) for k, v in val.items()}
            if "host" in srv:
                val = srv["host"]
                if not isinstance(val, str):
                    raise SystemExit(f"Config error: mcp.servers[{i}].host must be a string")
                s.host = val
            if "port" in srv:
                val = srv["port"]
                if not isinstance(val, int):
                    raise SystemExit(f"Config error: mcp.servers[{i}].port must be an integer")
                s.port = val
            config.mcp.servers.append(s)


# 用 SZTU_* 环境变量覆盖 config 中对应字段（若变量已设置）
def _apply_env(config: SztuConfig) -> None:
    host = os.environ.get("SZTU_HOST")
    if host is not None:
        config.host = host

    port_str = os.environ.get("SZTU_PORT")
    if port_str is not None:
        try:
            config.port = int(port_str)
        except ValueError:
            raise SystemExit(f"Config error: SZTU_PORT must be an integer, got: {port_str!r}")

    log_level = os.environ.get("SZTU_LOG_LEVEL")
    if log_level is not None:
        config.logging.level = log_level

    log_file = os.environ.get("SZTU_LOG_FILE")
    if log_file is not None:
        config.logging.file = log_file

    log_format = os.environ.get("SZTU_LOG_FORMAT")
    if log_format is not None:
        config.logging.format = log_format

    max_steps_str = os.environ.get("SZTU_MAX_STEPS")
    if max_steps_str is not None:
        try:
            val = int(max_steps_str)
            if val < 0:
                raise SystemExit(
                    "Config error: SZTU_MAX_STEPS must be a non-negative integer "
                    f"(0 = unlimited), got: {max_steps_str!r}"
                )
            config.agent.max_steps = val
        except ValueError:
            raise SystemExit(
                f"Config error: SZTU_MAX_STEPS must be an integer, got: {max_steps_str!r}"
            )

    # wrap-up / 结语宽限步 / stuck-loop 环境变量
    wrap_up_str = os.environ.get("SZTU_WRAP_UP_ON_MAX_STEPS")
    if wrap_up_str is not None:
        config.agent.wrap_up_on_max_steps = wrap_up_str.lower() not in ("0", "false", "no")
    grace_str = os.environ.get("SZTU_GRACE_STEP_ON_MAX_STEPS")
    if grace_str is not None:
        config.agent.grace_step_on_max_steps = grace_str.lower() not in ("0", "false", "no")
    for _env, _attr in (
        ("SZTU_STUCK_MAX_FAILURES", "stuck_max_failures"),
        ("SZTU_STUCK_MAX_TOTAL", "stuck_max_total"),
    ):
        _str = os.environ.get(_env)
        if _str is not None:
            try:
                val = int(_str)
                if val < 0:
                    raise SystemExit(
                        f"Config error: {_env} must be a non-negative integer, got: {_str!r}"
                    )
                setattr(config.agent, _attr, val)
            except ValueError:
                raise SystemExit(
                    f"Config error: {_env} must be an integer, got: {_str!r}"
                )

    llm_provider = os.environ.get("SZTU_LLM_PROVIDER")
    if llm_provider is not None:
        if llm_provider not in ("anthropic", "openai"):
            raise SystemExit(
                    "Config error: SZTU_LLM_PROVIDER must be 'anthropic' or 'openai',"
                    f" got: {llm_provider!r}"
                )
        config.llm.provider = llm_provider

    # SZTU_* is the supported name. Keep the original KAMA name so existing
    # project .env files remain valid while migrating to the SztuCode prefix.
    default_model = os.environ.get(
        "SZTU_LLM_DEFAULT_MODEL", os.environ.get("KAMA_LLM_DEFAULT_MODEL")
    )
    if default_model is not None:
        config.llm.default_model = default_model

    trace_enabled = os.environ.get("SZTU_TRACE_ENABLED")
    if trace_enabled is not None:
        config.trace.enabled = trace_enabled.lower() not in ("0", "false", "no")

    trace_file = os.environ.get("SZTU_TRACE_FILE")
    if trace_file is not None:
        config.trace.file = trace_file

    trace_payload = os.environ.get("SZTU_TRACE_INCLUDE_LLM_PAYLOAD")
    if trace_payload is not None:
        config.trace.include_llm_payload = trace_payload.lower() not in ("0", "false", "no")

    perm_timeout = os.environ.get("SZTU_PERMISSION_TIMEOUT_S")
    if perm_timeout is not None:
        try:
            perm_timeout_val = float(perm_timeout)
            if perm_timeout_val < 0:
                raise SystemExit(
                    f"Config error: SZTU_PERMISSION_TIMEOUT_S must be >= 0, got: {perm_timeout!r}"
                )
            config.permission.timeout_s = perm_timeout_val
        except ValueError:
            raise SystemExit(
                f"Config error: SZTU_PERMISSION_TIMEOUT_S must be a number, got: {perm_timeout!r}"
            )

    permission_mode = os.environ.get("SZTU_PERMISSION_MODE")
    if permission_mode is not None:
        if permission_mode not in {"normal", "accept_edits", "plan", "auto"}:
            raise SystemExit(f"Config error: SZTU_PERMISSION_MODE is invalid: {permission_mode!r}")
        config.permission.mode = permission_mode

    llm_context_window = os.environ.get("SZTU_LLM_CONTEXT_WINDOW")
    if llm_context_window is not None:
        try:
            llm_context_window_val = int(llm_context_window)
            if llm_context_window_val <= 0:
                raise SystemExit(
                    "Config error: SZTU_LLM_CONTEXT_WINDOW must be a positive "
                    f"integer, got: {llm_context_window!r}"
                )
            config.llm.context_window = llm_context_window_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_LLM_CONTEXT_WINDOW must be an integer, "
                f"got: {llm_context_window!r}"
            )

    compact_threshold = os.environ.get("SZTU_COMPACT_THRESHOLD")
    if compact_threshold is not None:
        try:
            compact_threshold_val = float(compact_threshold)
            if not (0.0 <= compact_threshold_val <= 1.0):
                raise SystemExit(
                    "Config error: SZTU_COMPACT_THRESHOLD must be between 0 and 1, "
                    f"got: {compact_threshold!r}"
                )
            config.compaction.auto_threshold = compact_threshold_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_COMPACT_THRESHOLD must be a number, "
                f"got: {compact_threshold!r}"
            )

    compact_tool_limit = os.environ.get("SZTU_COMPACT_TOOL_LIMIT")
    if compact_tool_limit is not None:
        try:
            compact_tool_limit_val = int(compact_tool_limit)
            if compact_tool_limit_val <= 0:
                raise SystemExit(
                    "Config error: SZTU_COMPACT_TOOL_LIMIT must be a positive integer, "
                    f"got: {compact_tool_limit!r}"
                )
            config.compaction.tool_result_limit = compact_tool_limit_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_COMPACT_TOOL_LIMIT must be an integer, "
                f"got: {compact_tool_limit!r}"
            )

    compact_tool_keep = os.environ.get("SZTU_COMPACT_TOOL_KEEP")
    if compact_tool_keep is not None:
        try:
            compact_tool_keep_val = int(compact_tool_keep)
            if compact_tool_keep_val <= 0:
                raise SystemExit(
                    "Config error: SZTU_COMPACT_TOOL_KEEP must be a positive integer, "
                    f"got: {compact_tool_keep!r}"
                )
            config.compaction.tool_result_keep = compact_tool_keep_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_COMPACT_TOOL_KEEP must be an integer, "
                f"got: {compact_tool_keep!r}"
            )

    # --- 上下文卸载环境变量 ---
    offload_enabled = os.environ.get("SZTU_OFFLOAD_ENABLED")
    if offload_enabled is not None:
        config.offload.enabled = offload_enabled.lower() not in ("0", "false", "no")

    offload_min_chars = os.environ.get("SZTU_OFFLOAD_MIN_CHARS")
    if offload_min_chars is not None:
        try:
            offload_min_chars_val = int(offload_min_chars)
            if offload_min_chars_val <= 0:
                raise SystemExit(
                    "Config error: SZTU_OFFLOAD_MIN_CHARS must be a positive integer, "
                    f"got: {offload_min_chars!r}"
                )
            config.offload.min_chars = offload_min_chars_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_OFFLOAD_MIN_CHARS must be an integer, "
                f"got: {offload_min_chars!r}"
            )

    offload_min_lines = os.environ.get("SZTU_OFFLOAD_MIN_LINES")
    if offload_min_lines is not None:
        try:
            offload_min_lines_val = int(offload_min_lines)
            if offload_min_lines_val <= 0:
                raise SystemExit(
                    "Config error: SZTU_OFFLOAD_MIN_LINES must be a positive integer, "
                    f"got: {offload_min_lines!r}"
                )
            config.offload.min_lines = offload_min_lines_val
        except ValueError:
            raise SystemExit(
                "Config error: SZTU_OFFLOAD_MIN_LINES must be an integer, "
                f"got: {offload_min_lines!r}"
            )

    # --- 运行预算环境变量 ---
    for _env, _attr in (
        ("SZTU_BUDGET_MAX_TOKENS", "max_tokens"),
        ("SZTU_BUDGET_MAX_WALL_CLOCK_S", "max_wall_clock_s"),
    ):
        _str = os.environ.get(_env)
        if _str is not None:
            try:
                val = int(_str)
                if val < 0:
                    raise SystemExit(
                        f"Config error: {_env} must be a non-negative integer, got: {_str!r}"
                    )
                setattr(config.budget, _attr, val)
            except ValueError:
                raise SystemExit(
                    f"Config error: {_env} must be an integer, got: {_str!r}"
                )
